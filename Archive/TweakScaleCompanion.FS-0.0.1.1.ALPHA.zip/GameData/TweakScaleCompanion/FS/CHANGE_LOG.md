# TweakScale Companion :: Firespitter :: Change Log

* 2020-0716: 0.0.1.1 (LisiasT) for KSP >= 1.4 Alpha
	+ Revised code for the `FSbuyoancy` scaler.
		- Now it works correctly, and I know why! :D
	+ Better (and safer) deactivation code using info gathered from [TweakScale](https://github.com/net-lisias-ksp/TweakScale/issues/125)
	+ Startup check for dependencies
* 2020-0531: 0.0.1.0 (LisiasT) for KSP >= 1.4 Alpha
	+ Initial Public Release
	+ Closes Issues:
		- [#1](https://github.com/net-lisias-ksp/TweakScaleCompantion_FS/issues/1) Weird issue with SXT parts using FSBuoyancy
		- [#2](https://github.com/net-lisias-ksp/TweakScaleCompantion_FS/issues/2) Properly Support FSBuoyancy
