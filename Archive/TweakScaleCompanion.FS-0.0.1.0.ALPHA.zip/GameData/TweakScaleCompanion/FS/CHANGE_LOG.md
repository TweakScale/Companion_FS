# TweakScale Companion :: Firespitter :: Change Log

* 2020-0531: 0.0.1.0 (LisiasT) for KSP >= 1.4 Alpha
	+ Initial Public Release
	+ Closes Issues:
	 	- [#1](https://github.com/net-lisias-ksp/TweakScaleCompantion_FS/issues/1) Weird issue with SXT parts using FSBuoyancy
		- [#2](https://github.com/net-lisias-ksp/TweakScaleCompantion_FS/issues/2) Properly Support FSBuoyancy
